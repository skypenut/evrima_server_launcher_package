@echo off
title Building EvrimaServerLauncher.exe
echo =========================================================
echo  Packaging EvrimaServerGUI.ps1 into Standalone EXE...
echo =========================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Compile-ToExe.ps1"
echo.
pause
